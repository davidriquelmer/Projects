from typing import List

from ..interfaces import Token

WordList = List[str]
TokenList = List[Token]
